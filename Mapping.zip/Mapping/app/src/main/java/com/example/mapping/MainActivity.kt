package com.example.mapping

import android.app.Activity
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.widget.SearchView
import com.example.mapping.R
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView

import java.util.*

class MainActivity : Activity() {
    private var map: MapView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        map = findViewById<MapView>(R.id.mapview)
        val searchView = findViewById<SearchView>(R.id.searchView)

        // Enable zoom controls and multi-touch
        map?.setMultiTouchControls(true)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    val geocoder = Geocoder(this@MainActivity, Locale.getDefault())
                    try {
                        val addressList: List<Address>? = geocoder.getFromLocationName(query, 1)

                        addressList?.let { list ->
                            if (list.isNotEmpty()) {
                                val address: Address = list[0]
                                val latitude = address.latitude
                                val longitude = address.longitude

                                // Move the map to the specified location
                                val mapController = map!!.controller
                                mapController.setZoom(15.0)
                                mapController.setCenter(GeoPoint(latitude, longitude))
                            } else {
                                // Handle case when no location found for the query
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        // Handle exception if geocoding fails
                    }
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Handle changes in the search query text (optional)
                return true
            }
        })
    }

    override fun onResume() {
        super.onResume()
        map?.onResume()
    }

    override fun onPause() {
        super.onPause()
        map?.onPause()
    }
}
